import React, { useState } from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import Api from '../Api';
import './Global.css';
import './Peladeiro.css';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';


function Peladeiro() {

    const [cidades, setCidades] = useState([]);
    const [uf, setUf] = useState('');
    const [nome, setNome] = useState('a')
    const [cidadeSelecionada, setCidadeSelecionada] = useState(null);
    const [cpf, setCPF] = useState('a')
    const [fone, setFone] = useState('1')
    const [celular, setCelular] = useState('1')
    const [dtcadastro, setDtCadastro] = useState(new Date().toLocaleDateString())
    const [dtinativado, setDtInativado] = useState('')
    const [endereco, setEndereco] = useState('a')
    const [numero, setNumero] = useState('1')
    const [email, setEmail] = useState('asd@gmas')

    async function obterCidades() {
        let resposta = await Api.get('/Cidade');
        setCidades(resposta.data);
    }

    async function salvar() {
        var objetoPeladeiro =
        {
            Nome: nome,
            CPF: cpf,
            Fone: fone,
            Celular: celular,
            DatCadastro: "2020-07-16",
            DatInativado: null,
            Endereço: endereco,
            Numero: numero,
            Email: email,
            CidadeId: cidadeSelecionada.id,
            // Cidade: cidadeSelecionada,
            DatNascimento: "1978-01-28"
        };

        console.log(objetoPeladeiro);
        const resposta = await Api.post('/Peladeiro', objetoPeladeiro);

        console.log(resposta);

        if (resposta.status === 201)
            alert(resposta.data);
        else
            alert('Dados inválidos');
    }

    function preencherCombo() {

        if (cidades.length === 0)
            obterCidades();

        return cidades.map((cidade, index) => {
            return (
                <option key={index} value={index}>{cidade.cidadeNome}</option>
            );
        });
    }

    function pegarCidade(event) {
        //Setar a UF
        let indiceArray = event.target.value;
        let cidade = cidades[indiceArray];

        setUf(cidade.uf);
        setCidadeSelecionada(cidade);
        console.log(cidade);
    }


    return (
        <>
            <div className="recuo">
                <TextField
                    label="CPF"
                    variant="outlined"
                    onChange={e => setCPF(e.target.value)}
                    value={cpf}
                />
                <TextField
                    label="Nome"
                    variant="outlined"
                    onChange={e => setNome(e.target.value)}
                    value={nome}
                />
                <TextField
                    label="Telefone"
                    variant="outlined"
                    onChange={e => setFone(e.target.value)}
                    value={fone}
                />
                <TextField
                    label="Celular"
                    variant="outlined"
                    onChange={e => setCelular(e.target.value)}
                    value={celular}
                />
                <TextField
                    label="Data Cadastro"
                    variant="outlined"
                    disabled
                    onChange={e => setDtCadastro(e.target.value)}
                    value={dtcadastro}
                />
                <TextField
                    label="Data Inativado"
                    variant="outlined"
                    disabled
                    onChange={e => setDtInativado(e.target.value)}
                    value={dtinativado}
                />
                <TextField
                    label="Endereco"
                    variant="outlined"
                    onChange={e => setEndereco(e.target.value)}
                    value={endereco}
                />
                <TextField
                    label="Numero"
                    variant="outlined"
                    onChange={e => setNumero(e.target.value)}
                    value={numero}
                />
                <TextField
                    label="E-mail"
                    variant="outlined"
                    onChange={e => setEmail(e.target.value)}
                    value={email}
                />
                <br></br>
                <div className="manterEmLinha">
                    <FormControl variant="outlined">
                        <InputLabel>Cidade</InputLabel>
                        <Select
                            native
                            id="comboCidade"
                            label="Cidade">
                            <option aria-label="None" value="" />
                            {preencherCombo()}
                        </Select>
                    </FormControl>
                    <div className="ufTamanho">
                        <TextField
                            disabled
                            fullWidth
                            label="UF"
                            defaultValue=" "
                            variant="outlined"
                            value={uf}
                        />
                    </div>
                </div >



            </div >
            <div className="botao">
                <div className="margem">
                    <Button variant="contained" color="primary" onClick={() => salvar()}>Salvar</Button>
                </div>
                <div className="margem">
                    <Button variant="contained" color="secondary">Cancelar</Button>
                </div>
            </div>
        </>
    );

}

export default Peladeiro;