import React from 'react';
import './App.css';
// import Valor from './Forms/Valor';
// import Cidade from './Forms/Cidade';
import Peladeiro from './Forms/Peladeiro';

function App() {
  
  return (
    <div className="App">
      <Peladeiro></Peladeiro>
      {/* <Cidade></Cidade> */}
    </div>
  );
}

export default App;